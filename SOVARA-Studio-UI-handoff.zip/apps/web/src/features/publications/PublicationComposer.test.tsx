// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import '../../test/setup';
import { PublicationComposer, vkMetadataLinkForSave } from './PublicationComposer';
import {
  createIntent,
  listAccounts,
  listPublicationStatus,
  publishIntent,
  retryPublication,
  startVkOAuth,
  startYouTubeOAuth,
} from './publication-api';

vi.mock('./publication-api', () => ({
  createIntent: vi.fn(),
  listAccounts: vi.fn(),
  listPublicationStatus: vi.fn(),
  removePreview: vi.fn(),
  retryPublication: vi.fn(),
  uploadPreview: vi.fn(),
  publishIntent: vi.fn(),
  startVkOAuth: vi.fn(),
  startYouTubeOAuth: vi.fn(),
}));

const intent = {
  id: 'c4c4e30-e24e-4cde-9534-a43f4b3f98e8',
  videoId: '4c4f8e30-e24e-4cde-9534-a43f4b3f98e8',
  platform: 'vk' as const,
  publishingAccountId: '5c4f8e30-e24e-4cde-9534-a43f4b3f98e8',
  mode: 'DRAFT' as const,
  title: 'News',
  description: null,
  link: null,
  createCommunityPost: false,
  scheduledAt: null,
  preview: null,
  revision: 0,
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z',
};

describe('PublicationComposer VK metadata link', () => {
  afterEach(cleanup);

  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(listAccounts).mockResolvedValue([
      { id: intent.publishingAccountId, platform: 'vk', displayName: 'VK', status: 'active' },
    ]);
    vi.mocked(listPublicationStatus).mockResolvedValue([]);
    vi.mocked(createIntent).mockResolvedValue(intent);
  });

  test('starts a new VK draft with the exact default link', async () => {
    render(<PublicationComposer />);
    fireEvent.change(screen.getByLabelText('Platform'), { target: { value: 'vk' } });
    expect(await screen.findByLabelText('VK metadata link (optional)')).toHaveValue(
      'https://vk.com/sovara_news',
    );
  });

  test('saves an intentional VK link clear without invoking publication behavior', async () => {
    render(<PublicationComposer />);
    fireEvent.change(screen.getByLabelText('Platform'), { target: { value: 'vk' } });
    fireEvent.change(await screen.findByLabelText('Account'), {
      target: { value: intent.publishingAccountId },
    });
    fireEvent.change(screen.getByLabelText('Ready video ID'), {
      target: { value: intent.videoId },
    });
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: 'News' } });
    fireEvent.change(screen.getByLabelText('VK metadata link (optional)'), {
      target: { value: '' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Save draft' }));

    await waitFor(() =>
      expect(createIntent).toHaveBeenCalledWith(
        expect.objectContaining({ link: null, mode: 'DRAFT' }),
      ),
    );
    expect(screen.getByText(/No publication has been started/)).toBeInTheDocument();
  });

  test('maps blank-only link input to a persisted clear', () => {
    expect(vkMetadataLinkForSave('  ')).toBeNull();
  });

  test('offers an explicit revision-bound retry only for FAILED publication', async () => {
    const failed = {
      id: '6c4f8e30-e24e-4cde-9534-a43f4b3f98e8',
      videoId: intent.videoId,
      platform: 'youtube' as const,
      publishingAccountId: intent.publishingAccountId,
      state: 'failed' as const,
      attemptCount: 2,
      revision: 7,
      nextAttemptAt: null,
      publishedAt: null,
      result: null,
      error: { code: 'PROVIDER_REJECTED', message: 'Publication failed.', retryable: true },
      updatedAt: '2026-01-01T00:00:00.000Z',
    };
    vi.mocked(listPublicationStatus).mockResolvedValue([failed]);
    vi.mocked(retryPublication).mockResolvedValue({ ...failed, state: 'queued', revision: 8 });
    render(<PublicationComposer />);

    fireEvent.click(await screen.findByRole('button', { name: 'Retry publication' }));
    await waitFor(() => expect(retryPublication).toHaveBeenCalledWith(failed.id, 7));
    expect(screen.getByText('Publication retry queued.')).toBeInTheDocument();
  });

  test('uses the just-uploaded ready video ID without manual entry', async () => {
    render(<PublicationComposer readyVideoId={intent.videoId} />);
    expect(await screen.findByLabelText('Ready video ID')).toHaveValue(intent.videoId);
  });

  test('starts YouTube OAuth and refreshes accounts after returning to Studio', async () => {
    const popup = {
      closed: false,
      close: vi.fn(),
    };
    vi.spyOn(window, 'open').mockReturnValue(popup as never);
    vi.mocked(startYouTubeOAuth).mockResolvedValue({ authorizationUrl: 'https://accounts.google.test/auth' });
    vi.mocked(listAccounts)
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        { id: intent.publishingAccountId, platform: 'youtube', displayName: 'YouTube', status: 'active' },
    ]);
    render(<PublicationComposer />);
    fireEvent.click(await screen.findByRole('button', { name: 'Подключить YouTube' }));

    await waitFor(() => expect(startYouTubeOAuth).toHaveBeenCalledOnce());
    window.dispatchEvent(new Event('focus'));
    await waitFor(() => expect(screen.getByRole('option', { name: 'YouTube' })).toBeInTheDocument());
  });

  test('starts VK OAuth and refreshes accounts after returning to Studio', async () => {
    vi.spyOn(window, 'open').mockReturnValue({ closed: false } as never);
    vi.mocked(startVkOAuth).mockResolvedValue({ authorizationUrl: 'https://id.vk.test/auth' });
    vi.mocked(listAccounts)
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        { id: intent.publishingAccountId, platform: 'vk', displayName: 'VK', status: 'active' },
      ]);
    render(<PublicationComposer />);
    fireEvent.change(screen.getByLabelText('Platform'), { target: { value: 'vk' } });
    fireEvent.click(await screen.findByRole('button', { name: 'Подключить VK' }));

    await waitFor(() => expect(startVkOAuth).toHaveBeenCalledOnce());
    window.dispatchEvent(new Event('focus'));
    await waitFor(() => expect(screen.getByRole('option', { name: 'VK' })).toBeInTheDocument());
  });

  test('publishes a saved draft once through the explicit action', async () => {
    vi.mocked(publishIntent).mockResolvedValue({ publicationId: intent.id });
    render(<PublicationComposer />);
    fireEvent.change(screen.getByLabelText('Platform'), { target: { value: 'vk' } });
    await screen.findByRole('option', { name: 'VK' });
    fireEvent.change(await screen.findByLabelText('Account'), {
      target: { value: intent.publishingAccountId },
    });
    fireEvent.change(screen.getByLabelText('Ready video ID'), { target: { value: intent.videoId } });
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: 'News' } });
    fireEvent.click(screen.getByRole('button', { name: 'Save draft' }));
    fireEvent.click(await screen.findByRole('button', { name: 'Publish now' }));

    await waitFor(() => expect(publishIntent).toHaveBeenCalledWith(intent.id, intent.revision));
    expect(screen.getByText('Publication queued.')).toBeInTheDocument();
  });
});
