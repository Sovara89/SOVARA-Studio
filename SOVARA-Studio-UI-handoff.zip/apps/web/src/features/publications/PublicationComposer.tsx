import { useEffect, useState } from 'react';
import type { PublicationStatusResponse, PublishingAccount } from './publication-api';
import type { PublicationIntentResponse } from '@sovara-studio/contracts';
import {
  createIntent,
  listAccounts,
  listPublicationStatus,
  publishIntent,
  removePreview,
  retryPublication,
  startVkOAuth,
  startYouTubeOAuth,
  uploadPreview,
} from './publication-api';

export function vkMetadataLinkForSave(value: string): string | null {
  return value.trim() || null;
}

function statusText(status: PublicationStatusResponse) {
  if (status.state === 'published') return 'published';
  if (status.state === 'publishing' || status.state === 'reconciling') return 'publishing';
  if (status.state === 'failed' || status.state === 'manual_review' || status.state === 'cancelled')
    return 'error';
  return 'pending';
}
export function PublicationComposer({ readyVideoId }: { readyVideoId?: string }) {
  const [accounts, setAccounts] = useState<PublishingAccount[]>([]);
  const [videoId, setVideoId] = useState('');
  const [platform, setPlatform] = useState<'youtube' | 'vk'>('youtube');
  const [accountId, setAccountId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [link, setLink] = useState('https://vk.com/sovara_news');
  const [community, setCommunity] = useState(false);
  const [preview, setPreview] = useState<File>();
  const [message, setMessage] = useState('');
  const [statuses, setStatuses] = useState<PublicationStatusResponse[]>([]);
  const [savedIntent, setSavedIntent] = useState<PublicationIntentResponse | null>(null);
  const [publishing, setPublishing] = useState(false);
  useEffect(() => {
    if (readyVideoId) setVideoId(readyVideoId);
  }, [readyVideoId]);
  useEffect(() => {
    void listAccounts()
      .then((value) => setAccounts(value.filter((account) => account.status === 'active')))
      .catch(() => setMessage('Publishing accounts are unavailable.'));
  }, []);
  const refreshAccounts = async () => {
    try {
      setAccounts((await listAccounts()).filter((account) => account.status === 'active'));
    } catch {
      setMessage('Publishing accounts are unavailable.');
    }
  };
  useEffect(() => {
    let active = true;
    const refresh = () =>
      void listPublicationStatus()
        .then((value) => active && setStatuses(value))
        .catch(() => active && setMessage('Publication status is temporarily unavailable.'));
    refresh();
    const timer = window.setInterval(refresh, 10_000);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, []);
  const available = accounts.filter((account) => account.platform === platform);
  const connectYouTube = async () => {
    try {
      setMessage('');
      const { authorizationUrl } = await startYouTubeOAuth();
      const popup = window.open(authorizationUrl, 'sovara-youtube-oauth', 'popup,width=600,height=700');
      if (!popup) throw new Error('Allow popups to connect YouTube.');
      const refreshAfterOAuth = () => {
        window.removeEventListener('focus', refreshAfterOAuth);
        void refreshAccounts();
      };
      window.addEventListener('focus', refreshAfterOAuth);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not start YouTube connection.');
    }
  };
  const connectVk = async () => {
    try {
      setMessage('');
      const { authorizationUrl } = await startVkOAuth();
      const popup = window.open(authorizationUrl, 'sovara-vk-oauth', 'popup,width=600,height=700');
      if (!popup) throw new Error('Allow popups to connect VK.');
      const refreshAfterOAuth = () => {
        window.removeEventListener('focus', refreshAfterOAuth);
        void refreshAccounts();
      };
      window.addEventListener('focus', refreshAfterOAuth);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not start VK connection.');
    }
  };
  const submit = async () => {
    try {
      setMessage('');
      const account = available.find((value) => value.id === accountId);
      if (!account) throw new Error('Select an active publishing account.');
      const created = await createIntent({
        videoId,
        platform,
        publishingAccountId: account.id,
        mode: 'DRAFT',
        scheduledAt: null,
        title,
        description: description || null,
        link: platform === 'vk' ? vkMetadataLinkForSave(link) : null,
        createCommunityPost: community,
      });
      const intent = preview ? await uploadPreview(created.id, preview, created.revision) : created;
      setSavedIntent(intent);
      setMessage(
        `${platform === 'youtube' ? 'YouTube' : 'VK'} intent saved. No publication has been started.`,
      );
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not save publication intent.');
    }
  };
  const publishNow = async () => {
    if (!savedIntent || publishing) return;
    try {
      setPublishing(true);
      setMessage('');
      await publishIntent(savedIntent.id, savedIntent.revision);
      setStatuses(await listPublicationStatus());
      setMessage('Publication queued.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not start publication.');
    } finally {
      setPublishing(false);
    }
  };
  const removeSavedPreview = async () => {
    if (!savedIntent?.preview) return;
    try {
      setMessage('');
      setSavedIntent(await removePreview(savedIntent.id, savedIntent.revision));
      setPreview(undefined);
      setMessage('Preview removed.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not remove preview.');
    }
  };
  const retryFailedPublication = async (status: PublicationStatusResponse) => {
    try {
      setMessage('');
      const retried = await retryPublication(status.id, status.revision);
      setStatuses((current) => current.map((item) => (item.id === retried.id ? retried : item)));
      setMessage('Publication retry queued.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not retry publication.');
    }
  };
  return (
    <section aria-labelledby="publication-composer">
      <h2 id="publication-composer">Publication composer</h2>
      <p>Only READY video IDs can be saved. Saving an intent never starts a publication.</p>
      <label>
        Ready video ID{' '}
        <input value={videoId} onChange={(event) => setVideoId(event.target.value)} required />
      </label>
      <label>
        Platform{' '}
        <select
          value={platform}
          onChange={(event) => {
            setPlatform(event.target.value as 'youtube' | 'vk');
            setAccountId('');
          }}
        >
          <option value="youtube">YouTube</option>
          <option value="vk">VK Video</option>
        </select>
      </label>
      <label>
        Account{' '}
        <select value={accountId} onChange={(event) => setAccountId(event.target.value)}>
          <option value="">Select account</option>
          {available.map((account) => (
            <option key={account.id} value={account.id}>
              {account.displayName ?? account.id}
            </option>
          ))}
        </select>
      </label>
      {platform === 'youtube' && (
        <button type="button" onClick={() => void connectYouTube()}>
          Подключить YouTube
        </button>
      )}
      {platform === 'vk' && (
        <button type="button" onClick={() => void connectVk()}>
          Подключить VK
        </button>
      )}
      <label>
        Title{' '}
        <input
          maxLength={100}
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          required
        />
      </label>
      <label>
        Description{' '}
        <textarea
          maxLength={platform === 'vk' ? 5000 : undefined}
          value={description}
          onChange={(event) => setDescription(event.target.value)}
        />
      </label>
      {platform === 'vk' && (
        <>
          <label>
            VK metadata link (optional){' '}
            <input
              type="url"
              maxLength={2048}
              value={link}
              onChange={(event) => setLink(event.target.value)}
              placeholder="https://vk.com/sovara_news"
            />
          </label>
          <label>
            <input
              type="checkbox"
              checked={community}
              onChange={(event) => setCommunity(event.target.checked)}
            />{' '}
            Create post in configured VK community
          </label>
        </>
      )}
      <label>
        Private preview{' '}
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(event) => setPreview(event.target.files?.[0])}
        />
      </label>
      <button type="button" onClick={() => void submit()}>
        Save draft
      </button>
      {savedIntent && (
        <button type="button" disabled={publishing} onClick={() => void publishNow()}>
          {publishing ? 'Publishing…' : 'Publish now'}
        </button>
      )}
      {savedIntent?.preview && (
        <button type="button" onClick={() => void removeSavedPreview()}>
          Remove preview
        </button>
      )}
      {message && <p role="status">{message}</p>}
      <section aria-labelledby="publication-status">
        <h3 id="publication-status">Publication status</h3>
        <p>Updates every 10 seconds. Statuses are grouped by platform and publishing account.</p>
        {statuses.length === 0 ? (
          <p>No publication jobs yet.</p>
        ) : (
          <ul>
            {statuses.map((status) => (
              <li key={status.id}>
                <strong>{status.platform === 'youtube' ? 'YouTube' : 'VK Video'}</strong> account{' '}
                {status.publishingAccountId}: {statusText(status)}
                {status.error && (
                  <span role="alert">
                    {' '}
                    — {status.error.code}: {status.error.message ?? 'No additional error detail'}
                  </span>
                )}
                {status.result && (
                  <span>
                    {' '}
                    — Result:{' '}
                    {status.result.remoteUrl ? (
                      <a href={status.result.remoteUrl}>View published video</a>
                    ) : (
                      status.result.remoteMediaId
                    )}
                  </span>
                )}
                {status.state === 'failed' && (
                  <button type="button" onClick={() => void retryFailedPublication(status)}>
                    Retry publication
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </section>
  );
}
