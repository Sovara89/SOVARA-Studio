import { FormEvent, useEffect, useState } from 'react';
import { RouterProvider } from '@tanstack/react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { router } from './router';
import { signIn, signOut, unauthorizedEvent, useSession } from '../lib/auth-client';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
});

export function App() {
  const { data: session, isPending } = useSession();
  const [unauthorized, setUnauthorized] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    const showLogin = () => setUnauthorized(true);
    window.addEventListener(unauthorizedEvent, showLogin);
    return () => window.removeEventListener(unauthorizedEvent, showLogin);
  }, []);
  const login = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    const result = await signIn({ email, password });
    if (result.error) return setError(result.error.message ?? 'Could not sign in.');
    window.location.reload();
  };
  const logout = async () => {
    await signOut();
    setUnauthorized(true);
  };
  if (isPending) return null;
  return (
    <QueryClientProvider client={queryClient}>
      {!session?.user || unauthorized ? (
        <main>
          <h1>SOVARA Studio</h1>
          <form onSubmit={(event) => void login(event)}>
            <label>
              Email <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
            </label>
            <label>
              Password{' '}
              <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
            </label>
            <button type="submit">Войти</button>
            {error && <p role="alert">{error}</p>}
          </form>
        </main>
      ) : (
        <>
          <button type="button" onClick={() => void logout()}>
            Выйти
          </button>
          <RouterProvider router={router} />
        </>
      )}
    </QueryClientProvider>
  );
}
