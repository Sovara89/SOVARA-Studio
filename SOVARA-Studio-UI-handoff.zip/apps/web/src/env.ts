export const apiBaseUrl = import.meta.env.VITE_API_URL ?? '/api';
