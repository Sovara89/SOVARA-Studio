import { describe, expect, test, vi } from 'vitest';
import { createYouTubePublisher } from '@sovara-studio/platforms';
import { createPublicationJobProcessor } from './publication-job-processor.js';

const publication = {
  id: '4c4f8e30-e24e-4cde-9534-a43f4b3f98e8',
  userId: '8f6a7c3b-8e7b-4f54-9e4a-1b2c3d4e5f60',
  revision: 0,
  state: 'queued' as const,
  platform: 'youtube' as const,
  nextAttemptAt: null,
};

function job() {
  return {
    id: 'publication-4c4f8e30-e24e-4cde-9534-a43f4b3f98e8-r0',
    data: { publicationId: publication.id, expectedRevision: 0 },
  } as never;
}

describe('publication job processor', () => {
  test('does not claim a publication without a registered publisher', async () => {
    const claimPublication = vi.fn();
    const publications = {
      findById: vi.fn().mockResolvedValue([publication]),
      claimPublication,
    } as never;

    const result = await createPublicationJobProcessor({
      publications,
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
    })(job());

    expect(result).toEqual({ outcome: 'unsupported', reason: 'no_publisher' });
    expect(claimPublication).not.toHaveBeenCalled();
  });

  test('does not claim a stale revision during redelivery', async () => {
    const claimPublication = vi.fn();
    const publications = {
      findById: vi.fn().mockResolvedValue([{ ...publication, revision: 1 }]),
      claimPublication,
    } as never;

    const result = await createPublicationJobProcessor({
      publications,
      executors: new Map([['youtube', { executeAfterRequestSent: vi.fn() }]]),
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
    })(job());

    expect(result).toEqual({ outcome: 'skipped', reason: 'stale_or_terminal' });
    expect(claimPublication).not.toHaveBeenCalled();
  });

  test('claims, records request intent, and settles through the repository', async () => {
    const events: string[] = [];
    const markAttemptRequestSent = vi.fn().mockImplementation(async () => {
      events.push('request_sent');
      return [{ id: 'attempt-1', revision: 1, state: 'request_sent' }];
    });
    const settleDefinitiveSuccess = vi.fn().mockResolvedValue(undefined);
    const claimed = {
      publication: {
        ...publication,
        state: 'publishing' as const,
        revision: 1,
        leaseToken: 'lease-token',
        userId: publication.userId,
      },
      attempt: { id: 'attempt-1', revision: 0, state: 'started' as const },
    };
    const publications = {
      findById: vi.fn().mockResolvedValue([publication]),
      claimPublication: vi.fn().mockResolvedValue(claimed),
      renewPublicationLease: vi.fn().mockResolvedValue([claimed.publication]),
      markAttemptRequestSent,
      markAmbiguous: vi.fn().mockResolvedValue(undefined),
      settleDefinitiveSuccess,
    } as never;
    const executeAfterRequestSent = vi.fn(async (context) => {
      events.push(`executor:${context.attempt.state}`);
      await context.settleSuccess(null, 'remote-media-1');
    });

    const result = await createPublicationJobProcessor({
      publications,
      executors: new Map([['youtube', { executeAfterRequestSent }]]),
      legacyCredentialOwnership: () => ({
        accountId: 'account-1',
        userId: publication.userId,
        platform: 'youtube',
        credentialRevision: 0,
      }),
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
    })(job());

    expect(result).toEqual({ outcome: 'processed' });
    expect(executeAfterRequestSent).toHaveBeenCalledOnce();
    expect(events).toEqual(['request_sent', 'executor:request_sent']);
    expect(settleDefinitiveSuccess).toHaveBeenCalledWith(
      publication.userId,
      publication.id,
      'attempt-1',
      1,
      1,
      null,
      'remote-media-1',
      undefined,
      { expectedLeaseToken: 'lease-token' },
    );
  });

  test('does not invoke the executor when request intent persistence fails', async () => {
    const executeAfterRequestSent = vi.fn();
    const publications = {
      findById: vi.fn().mockResolvedValue([publication]),
      claimPublication: vi.fn().mockResolvedValue({
        publication: {
          ...publication,
          state: 'publishing',
          revision: 1,
          leaseToken: 'lease-token',
        },
        attempt: { id: 'attempt-1', revision: 0, state: 'started' },
      }),
      markAttemptRequestSent: vi.fn().mockResolvedValue([]),
    } as never;

    await expect(
      createPublicationJobProcessor({
        publications,
        executors: new Map([['youtube', { executeAfterRequestSent }]]),
        legacyCredentialOwnership: () => ({
          accountId: 'account-1',
          userId: publication.userId,
          platform: 'youtube',
          credentialRevision: 0,
        }),
        leaseDurationMs: 1_000,
        leaseHeartbeatMs: 100,
      })(job()),
    ).resolves.toEqual({ outcome: 'skipped', reason: 'request_intent_stale' });
    expect(executeAfterRequestSent).not.toHaveBeenCalled();
  });

  test('moves an executor failure toward reconciliation after request intent', async () => {
    const markAmbiguous = vi.fn().mockResolvedValue(undefined);
    const publications = {
      findById: vi.fn().mockResolvedValue([publication]),
      claimPublication: vi.fn().mockResolvedValue({
        publication: {
          ...publication,
          state: 'publishing',
          revision: 1,
          leaseToken: 'lease-token',
        },
        attempt: { id: 'attempt-1', revision: 0, state: 'started' },
      }),
      markAttemptRequestSent: vi
        .fn()
        .mockResolvedValue([{ id: 'attempt-1', revision: 1, state: 'request_sent' }]),
      markAmbiguous,
    } as never;
    const executeAfterRequestSent = vi.fn().mockRejectedValue(new Error('provider timeout'));

    await expect(
      createPublicationJobProcessor({
        publications,
        executors: new Map([['youtube', { executeAfterRequestSent }]]),
        legacyCredentialOwnership: () => ({
          accountId: 'account-1',
          userId: publication.userId,
          platform: 'youtube',
          credentialRevision: 0,
        }),
        leaseDurationMs: 1_000,
        leaseHeartbeatMs: 100,
      })(job()),
    ).rejects.toThrow('provider timeout');
    expect(markAmbiguous).toHaveBeenCalledOnce();
  });

  test('preflights before request intent and invokes the generic publisher afterward', async () => {
    const events: string[] = [];
    const claimed = {
      publication: {
        ...publication,
        state: 'publishing' as const,
        revision: 1,
        leaseToken: 'lease-token',
      },
      attempt: { id: 'attempt-1', revision: 0, state: 'started' as const },
    };
    const markAttemptRequestSent = vi.fn().mockImplementation(async () => {
      events.push('request_sent');
      return [{ id: 'attempt-1', revision: 1, state: 'request_sent' as const }];
    });
    const settleDefinitiveSuccess = vi.fn().mockResolvedValue(undefined);
    const publish = vi.fn(async (context) => {
      events.push(`publish:${context.attemptId}`);
      return {
        kind: 'published' as const,
        remote: { remoteMediaId: 'remote-media-1' },
      };
    });
    const publications = {
      findById: vi.fn().mockResolvedValue([publication]),
      claimPublication: vi.fn().mockImplementation(async () => {
        events.push('claim');
        return claimed;
      }),
      renewPublicationLease: vi.fn().mockResolvedValue([claimed.publication]),
      markAttemptRequestSent,
      settleDefinitiveSuccess,
    } as never;
    const preflight = vi.fn().mockImplementation(async () => {
      events.push('preflight');
      return {
        credential: {
          accountId: 'account-1',
          userId: publication.userId,
          platform: 'youtube',
          credentialRevision: 1,
          accessToken: 'access-token',
          providerAccountId: 'channel-1',
          scopes: ['https://www.googleapis.com/auth/youtube.upload'],
          getAccessToken: vi.fn().mockResolvedValue('access-token'),
        },
        media: {
          sizeBytes: 10,
          contentType: 'video/mp4',
          openReadStream: vi.fn(),
        },
      };
    });

    const result = await createPublicationJobProcessor({
      publications,
      publishers: new Map([['youtube', { platform: 'youtube', publish, reconcile: vi.fn() }]]),
      preflight,
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
    })(job());

    expect(result).toEqual({ outcome: 'processed' });
    expect(events).toEqual(['claim', 'preflight', 'request_sent', 'publish:attempt-1']);
    expect(settleDefinitiveSuccess).toHaveBeenCalledWith(
      publication.userId,
      publication.id,
      'attempt-1',
      1,
      1,
      undefined,
      'remote-media-1',
      undefined,
      { expectedLeaseToken: 'lease-token' },
    );
  });

  test('keeps no-ID reconciliation on the same attempt and redelivery cannot initiate upload', async () => {
    const providerRequest = vi.fn();
    const publisher = createYouTubePublisher({ fetch: providerRequest });
    const reconciling = {
      ...publication,
      revision: 3,
      state: 'reconciling' as const,
      reconciliationRequiredAt: new Date(1_000),
      attemptCount: 1,
      createdAt: new Date(0),
    };
    const claimed = {
      publication: {
        ...reconciling,
        revision: 4,
        leaseToken: 'reconciliation-lease',
      },
      attempt: {
        id: 'attempt-1',
        revision: 2,
        state: 'ambiguous' as const,
        requestSentAt: new Date(500),
        startedAt: new Date(400),
        providerRequestId: null,
        remoteOwnerId: null,
        remoteMediaId: null,
        remoteUrl: null,
      },
    };
    const reconcileUnresolved = vi.fn().mockResolvedValue(undefined);
    const claimPublication = vi.fn();
    const publications = {
      findById: vi
        .fn()
        .mockResolvedValueOnce([reconciling])
        .mockResolvedValueOnce([{ ...reconciling, revision: 5 }]),
      claimPublication,
      claimReconciliation: vi.fn().mockResolvedValue(claimed),
      renewPublicationLease: vi.fn().mockResolvedValue([claimed.publication]),
      reconcileUnresolved,
      markManualReview: vi.fn(),
    } as never;
    const preflight = vi.fn().mockResolvedValue({
      credential: {
        accountId: 'account-1',
        userId: publication.userId,
        platform: 'youtube',
        credentialRevision: 1,
        accessToken: 'token',
        providerAccountId: 'channel-1',
        scopes: ['https://www.googleapis.com/auth/youtube.upload'],
        getAccessToken: vi.fn().mockResolvedValue('token'),
      },
      media: { sizeBytes: 1, contentType: 'video/mp4', openReadStream: vi.fn() },
    });
    const processor = createPublicationJobProcessor({
      publications,
      publishers: new Map([['youtube', publisher]]),
      preflight,
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
      now: () => new Date(2_000),
    });
    const reconciliationJob = {
      id: 'reconcile-job',
      data: { publicationId: publication.id, expectedRevision: 3 },
    } as never;

    await expect(processor(reconciliationJob)).resolves.toMatchObject({ outcome: 'processed' });
    await expect(processor(reconciliationJob)).resolves.toEqual({
      outcome: 'skipped',
      reason: 'stale_or_terminal',
    });
    expect(reconcileUnresolved).toHaveBeenCalledOnce();
    expect(claimPublication).not.toHaveBeenCalled();
    expect(providerRequest).not.toHaveBeenCalled();
  });

  test('bounds reconciliation credential failures by max age and settles manual review', async () => {
    const reconciling = {
      ...publication,
      revision: 3,
      state: 'reconciling' as const,
      reconciliationRequiredAt: new Date(9_000),
      attemptCount: 1,
      createdAt: new Date(0),
    };
    const claimed = {
      publication: { ...reconciling, revision: 4, leaseToken: 'reconciliation-lease' },
      attempt: {
        id: 'attempt-1',
        revision: 2,
        state: 'ambiguous' as const,
        requestSentAt: new Date(1_000),
        startedAt: new Date(900),
      },
    };
    const markManualReview = vi.fn().mockResolvedValue(undefined);
    const reconcileUnresolved = vi.fn();
    const publications = {
      findById: vi.fn().mockResolvedValue([reconciling]),
      claimReconciliation: vi.fn().mockResolvedValue(claimed),
      renewPublicationLease: vi.fn().mockResolvedValue([claimed.publication]),
      markManualReview,
      reconcileUnresolved,
    } as never;
    const publisher = {
      platform: 'youtube' as const,
      publish: vi.fn(),
      reconcile: vi.fn(),
    };
    const retryPolicy = {
      maxProviderAttempts: 5,
      baseDelayMs: 100,
      maxDelayMs: 1_000,
      maxRetryWindowMs: 100_000,
      reconciliationDelayMs: 500,
      reconciliationMaxAgeMs: 5_000,
      maxProviderRetryAfterMs: 1_000,
    };
    const processor = createPublicationJobProcessor({
      publications,
      publishers: new Map([['youtube', publisher]]),
      preflight: vi.fn().mockRejectedValue(new Error('credential unavailable')),
      leaseDurationMs: 1_000,
      leaseHeartbeatMs: 100,
      retryPolicy,
      now: () => new Date(10_000),
    });

    await expect(
      processor({
        id: 'reconcile-credential-job',
        data: { publicationId: publication.id, expectedRevision: 3 },
      } as never),
    ).resolves.toMatchObject({
      outcome: 'processed',
      reason: 'reconciliation_unresolved',
    });
    expect(markManualReview).toHaveBeenCalledOnce();
    expect(reconcileUnresolved).not.toHaveBeenCalled();
    expect(publisher.publish).not.toHaveBeenCalled();
    expect(publisher.reconcile).not.toHaveBeenCalled();
  });
});
